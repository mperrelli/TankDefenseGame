import java.awt.Color;


public class Optank {
	float x, y;
	int level;
	int startinglevel;
	
	public Optank(float x, float y, int level){
		this.x = x;
		this.y = y;
		this.level = level;
		this.startinglevel = level;
	}

}
