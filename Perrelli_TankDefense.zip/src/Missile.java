
public class Missile {
	float x, y;
	
	public Missile(float x, float y){
		this.x = x;
		this.y = y;
	}

}
